## 说明

这是一个固定 v4.45.2 版本的 V2RAY 脚本安装, 避免一些莫名其妙无法运行的问题。

## 警告

此脚本版本已废弃，不再添加任何功能，也不修复任何问题。

请使用：https://github.com/233boy/v2ray/tree/master

除非你有特殊需求，要不然请尽量不要使用此版本。

## 安装

```bash
wget https://github.com/233boy/v2ray/archive/old.tar.gz -O v2ray-old.tar.gz;tar -zxvf v2ray-old.tar.gz;cd v2ray-old;chmod +x i*;./i* local
```